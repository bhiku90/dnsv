import React from 'react';
import { tokens } from "../../theme";
import { Box, Typography, useTheme } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import Header from "../../components/Header";

function MddTable1({data}) {
    const theme = useTheme();

    console.log("barData:------",data);
    const rows = [];
    Object.entries(data).forEach(([domainIndex, domainDataArray]) => {
        domainDataArray.forEach((item, ipIndex) => {
            rows.push({
                id: `${domainIndex}-${ipIndex}`, // Unique ID for each row
                fqdn: item.fqdn || 'NA', // Only display fqdn for the first IP of the group
                ip: item.data.map((d) => d.ip || 'N/A').join(", "),
                status: item.data.map((d) => d.status).join(", "),
                location: item.data.map((d) => d.location).join(", "),
                activedate: item.data.map((d) => d.activedate[0]).join(", "),
                inactivedate: item.data.map((d) => d.inactivedate?.[0] || 'N/A').join(", "),
                registrar: Array.isArray(item.registrar) ? item.registrar.join(", ") : item.registrar,
                registrant: Array.isArray(item.registrant) ? item.registrant.join(",") : item.registrant
            });
        });
    });

    const columns = [
        {
            field: "fqdn",
            headerName: "Domain Name",
            flex: 1,
            cellClassName: "name-column--cell",
            renderCell: (params) => (
                <div style={{ whiteSpace: 'normal', lineHeight: 'normal' }}>{params.value}</div>
            ),
        },
        {
            field: "ip",
            headerName: "IP Addresses",
            flex: 1
        },
        {
            field: "status",
            headerName: "Status",
            flex: 1
        },
        {
            field: "location",
            headerName: "Geo-Location",
            flex: 1
        },
        {
            field: "registrar",
            headerName: "Registrar",
            flex: 1
        },
        {
            field: "registrant",
            headerName: "Registrant",
            flex: 1
        },
        {
            field: "activedate",
            headerName: "Active Date",
            flex: 1
        },
        {
            field: "inactivedate",
            headerName: "Inactive Date",
            flex: 1
        }
    ];

  return (
    <Box m="20px">
        {/* <Header subtitle={`Data For IP: ${''}`}/> */}
        <button onClick={''}>Back to Chart</button>
        <Box m="40px 0 0 0" height="75vh">
            <DataGrid rows={rows} columns={columns}/>
        </Box>
    </Box>
  )
}

export default MddTable1;