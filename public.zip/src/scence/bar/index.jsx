import { Box } from "@mui/material";
import Header from "../../components/Header";
import BarChartMal from "../../components/BarChartMal";
import MddTable1 from "../mddTables";
import { useState } from "react";

const BarMal = () =>{
    const [selectBar,setSelectedBar] = useState(null);

    const handleBarClick= (barData) => {
        setSelectedBar(barData);
        
    }



    return(
        <Box>
            <Header title="Bar Chart For Mal and DGA" subtitle="Simple Bar Chart"/>
            <Box height="75vh">
                {!selectBar ? (
                    <BarChartMal onBarClick={handleBarClick} />  
                ):(
                    <MddTable1 data={{...selectBar}}/>
                )};
            </Box>
        </Box>
    );
}

export default BarMal;